---
name: Kiswah Royale
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#e1c561'
  on-secondary: '#3b2f00'
  secondary-container: '#796400'
  on-secondary-container: '#ffe380'
  tertiary: '#f7c852'
  on-tertiary: '#3e2e00'
  tertiary-container: '#d9ad39'
  on-tertiary-container: '#584200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#fee179'
  secondary-fixed-dim: '#e1c561'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#554500'
  tertiary-fixed: '#ffdf98'
  tertiary-fixed-dim: '#eec14b'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4300'
  background: '#111317'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-xl-mobile:
    fontFamily: Noto Serif
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.005em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels the revered grandeur of the Holy Ka'bah's draped silk (the Kiswah), weaving solemn reverence with regal clarity. Crafted specifically for pilgrims embarking on Hajj and Umrah, the aesthetic balances the solemnity of spiritual devotion with opulent craftsmanship. Every touchpoint feels intentional, quiet, and sacred—mirroring the tactile contrast between midnight jacquard weave and thick, hand-stitched 24k gold bullion wire (Thuluth calligraphy).

The style merges **Minimalist Precision** with **Tactile Luxury**. Dense, deep-spectrum blacks absorb visual noise to eliminate distraction during rituals, while polished gold and warm ivory guide visual priority with celestial distinction. The emotional response is one of profound composure, sacred honor, and effortless digital sanctuary amidst crowded physical journeys.

## Colors

The palette reproduces the interplay of radiant gold thread against deep-dyed raw silk:

- **Primary (`#d4af37`)**: The definitive 24k gold leaf tone, reserved for critical interaction states, primary callouts, and sacred milestones.
- **Secondary (`#e6ca65`)**: Radiant highlight gold, providing delicate shimmer, focus rings, and high-priority active accents.
- **Tertiary (`#c59b27`)**: Antique, burnished gold used for borders, subtle icons, badges, and secondary interactive moments.
- **Background & Base Neutrals**:
  - `Canvas / Absolute Deep Black`: `#0d0f12` (Obsidian foundation)
  - `Surface / Velvet Black`: `#14171c` (Elevated card containers and structural panels)
  - `Surface High / Charcoal Night`: `#1c2027` (Hover states and modal overlays)
- **Text & Foreground**:
  - `Text Primary`: `#f5f3eb` (Warm unbleached ivory for high legibility without harsh clinical white glare)
  - `Text Muted`: `#9ea3ae` (Subordinate liturgical descriptions, timestamps, and metadata)
- **Structural Lines**: `#2a2e37` (Muted charcoal border offering crisp definition with an imperceptible golden undertone)

## Typography

The typographical pairing respects classical manuscript tradition alongside functional mobile utility.

- **Headlines (Noto Serif)**: Evokes the monumentality of Quranic stone inscriptions and gold-stitched Thuluth bands (*Hizam*). Its chiselled serifs and vertical poise command reverence in titles, prayer titles, and sacred verses.
- **Body & Labels (Manrope)**: Delivers geometric neutrality, optimal legibility during motion (such as performing Tawaf or Sa'i), and clarity across small touch interfaces in direct sunlight. Labels utilize widened letter-spacing to emulate ceremonial gold engravings.

## Layout & Spacing

The layout is built upon an 8pt architectural rhythm, utilizing generous vertical breathing room to inspire calm and contemplation.

- **Mobile Viewports (<768px)**: A 4-column fluid layout with `1rem` margins and gutters. Bottom navigation is prioritized to facilitate one-handed thumb interaction during walking and prayer stages.
- **Tablet Viewports (768px - 1024px)**: An 8-column layout expanding margins to `2rem`, allowing structured dual-pane ritual progression trackers.
- **Desktop Viewports (>1024px)**: A 12-column restrained grid capped at 1280px max-width, keeping reading tracks centered and solemn rather than stretched across panoramic widths.

## Elevation & Depth

Depth mimics physical layered cloth, stone, and burnished metallic leaf rather than synthetic drop shadows:

- **Surface Layering**: Strict progression from background Obsidian (`#0d0f12`) to card Velvet (`#14171c`), up to active modal surfaces (`#1c2027`).
- **Gold-Rimmed Outlines**: Cards, popovers, and elevated modules use `1px` crisp borders tinted in `#2a2e37`. When hovered or active, borders transition into an illuminated gold hairline border (`#c59b27`).
- **Atmospheric Golden Auroras**: Elevated floating actions and critical spiritual moments (e.g., Qibla compass alignment, completion of Tawaf) deploy an ambient, warm gold glow: `0px 12px 32px -4px rgba(212, 175, 55, 0.18)`.

## Shapes

The design uses conservative, structured soft corners (`roundedness: 1`). Radii are kept small (`0.25rem` standard, `0.5rem` for cards, `0.75rem` for large modals) to honor the architectural cubic geometry of the Ka'bah itself (*Al-Ka'bah* literally meaning "The Cube"). Overly pill-shaped or bulbous radii are deliberately avoided to maintain solemn dignity and gravitas.

## Components

### Buttons
- **Primary**: Solid 24k gold (`#d4af37`) background with Obsidian text (`#0d0f12`), weighted in `Manrope` SemiBold. Hover brings out a bright auric sheen (`#e6ca65`).
- **Secondary**: Velvet black surface (`#14171c`) framed with a 1px border in `#c59b27` and ivory text (`#f5f3eb`).
- **Tertiary / Ghost**: Clear background, `#f5f3eb` label, with gold text transition on hover.

### Cards
- Velvet black (`#14171c`) base encased in a subtle `#2a2e37` boundary. For featured ritual guides, cards feature an ornamental gold hairline accent along the top edge (`#d4af37`, height: 2px).

### Input Fields & Controls
- **Inputs**: Velvet black backgrounds with `#2a2e37` outlines that illuminate with a 1px `#e6ca65` halo on focus. Caret and active icons match the primary gold tone.
- **Checkboxes & Radios**: Obsidian square/circle shapes bounded by `#2a2e37`, displaying a pure `#d4af37` fill and obsidian checkmark when completed.

### Ritual Chips & Badges
- Compact indicators (e.g., "Miqat Reached", "Dua Recommended") rendered with an ultra-subtle tint (`rgba(212, 175, 55, 0.08)`), framed by `#c59b27` borders, and set in uppercase `label-sm` ivory type.

### Specialized Domain Components
- **Tawaf / Sa'i Counter**: High-contrast, monumental numeric displays (`Noto Serif`) enclosed in a gold-bordered concentric ring with haptic completion pulses.
- **Quranic Scripture Display**: Ivory text set on an Obsidian field, bordered by symmetrical filigree corner accents inspired by Kiswah embroidery bands.