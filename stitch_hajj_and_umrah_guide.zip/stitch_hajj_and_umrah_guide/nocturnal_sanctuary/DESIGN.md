---
name: Nocturnal Sanctuary
colors:
  surface: '#081612'
  surface-dim: '#081612'
  surface-bright: '#2e3c37'
  surface-container-lowest: '#04110d'
  surface-container-low: '#101e1a'
  surface-container: '#14221e'
  surface-container-high: '#1e2d28'
  surface-container-highest: '#293833'
  on-surface: '#d6e6df'
  on-surface-variant: '#d1c5b2'
  inverse-surface: '#d6e6df'
  inverse-on-surface: '#25332f'
  outline: '#9a8f7e'
  outline-variant: '#4e4637'
  surface-tint: '#edc065'
  primary: '#ffd685'
  on-primary: '#402d00'
  primary-container: '#e5b95f'
  on-primary-container: '#654900'
  inverse-primary: '#7a5900'
  secondary: '#9cd2ba'
  on-secondary: '#003828'
  secondary-container: '#1a503d'
  on-secondary-container: '#8bc0a9'
  tertiary: '#ffd682'
  on-tertiary: '#402d00'
  tertiary-container: '#e6b957'
  on-tertiary-container: '#654900'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea2'
  primary-fixed-dim: '#edc065'
  on-primary-fixed: '#261900'
  on-primary-fixed-variant: '#5c4200'
  secondary-fixed: '#b8eed6'
  secondary-fixed-dim: '#9cd2ba'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#1a503d'
  tertiary-fixed: '#ffdea0'
  tertiary-fixed-dim: '#eec05e'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#081612'
  on-background: '#d6e6df'
  surface-variant: '#293833'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system crafts a deeply spiritual, reverent, and nocturnal sanctuary for the sacred journey of Hajj and Umrah. Drawing aesthetic cues from night prayers under obsidian desert skies, illuminated marble courtyards, and gold-leaf calligraphy, the aesthetic pairs profound stillness with tactile Islamic luxury.

The style synthesizes high-end architectural minimalism with atmospheric glassmorphism. Interfaces feel quiet, luminous, and weightless—allowing pilgrims to maintain focus, devotion, and effortless spatial navigation during demanding rites. Visual weight is anchored in deep mineral emeralds and illuminated by delicate metallic gold filaments.

## Colors

The color palette reflects the nocturnal majesty of the holy sanctuaries:

- **Primary (`#e5b95f`):** Luminous metallic gold, evoking the embroidered Kiswah and ambient warm lanterns. Used for sacred status signifiers, primary actions, and pivotal navigation indicators.
- **Secondary (`#86bba4`):** Soft celadon sage, reflecting cool courtyard marble, relief, and peace. Serves as functional confirmation, secondary data visualizations, and complementary highlights.
- **Tertiary (`#cda243`):** Burnished antique gold for borders, delicate divider lines, active states, and decorative calligraphic motifs.
- **Neutral Surface Hierarchy:**
  - `Base Canvas`: Deep obsidian emerald black (`#061410`).
  - `Surface Container Low`: Obsidian pine (`#081a15`).
  - `Surface Container Mid`: Night forest (`#0b221c`).
  - `Surface Container High`: Translucent emerald glass (`rgba(11, 34, 28, 0.7)`).
- **Text & Content:**
  - `Text Crisp`: Warm ivory (`#f5f8f6`) for high legibility against pitch backgrounds.
  - `Text Muted`: Celestial sage mist (`#a8c0b5`) for subtitles, metadata, and structural guides.

## Typography

Typography bridges devotional transcendence and crisp utility. 

- **Display & Headlines (`Newsreader`):** An authoritative, warm transitional serif with balanced proportions and literary cadence. It delivers reverence for Dua headers, ritual steps, and section benchmarks.
- **Body & Labels (`Plus Jakarta Sans`):** Clean, geometric, and modern, offering uncompromised clarity for low-light legibility, counts, instructions, and maps under desert glare or midnight rites.

## Layout & Spacing

A fluid responsive grid is combined with expansive negative space to induce tranquility and calm the pilgrim's senses:

- **Mobile (< 768px):** 4-column layout with `1rem` margins and gutters. Single-column stacked rituals with ample touch targets (minimum 48px).
- **Tablet (768px - 1024px):** 8-column layout with `1.5rem` margins and gutters. Dual split-pane view for guides alongside interactive maps.
- **Desktop (> 1024px):** 12-column layout centered within a max-width container of `1280px`, anchored by `3rem` margins to preserve an intimate, boutique sanctuary presence without stretching content.

## Elevation & Depth

Visual hierarchy relies on luminous layering rather than heavy drop shadows, mimicking backlit onyx, lanterns, and celestial radiance:

- **Surface Layering:** Interfaces build from the abyss (`#061410`) up through floating slabs of obsidian emerald glass (`rgba(11, 34, 28, 0.75)` with `16px` backdrop-blur).
- **Subtle Gold Filaments:** Higher elevation elements do not rely on strong drop shadows; they are defined by hairline borders (`1px solid rgba(229, 185, 95, 0.25)`).
- **Ambient Aura Glow:** Elevated modals and active status cards project an ultra-diffused, soft golden halo (`box-shadow: 0 12px 40px rgba(229, 185, 95, 0.08)`).
- **Pressed & Resting States:** Inactive elements blend smoothly into deep surfaces; interactive items lift forward on focus with a slight shift in celadon border brightness.

## Shapes

The design system employs a refined `rounded-2xl` curvature language across primary cards and modals (`1rem` base roundedness, scaling to `1.5rem` on larger modular panels). This curvature softens technical edges, subtly referencing traditional Islamic arches and smooth pilgrimage river stones without resorting to full novelty geometry.

## Components

- **Buttons:**
  - *Primary Gold Button:* Filled with a gradient from `#e5b95f` to `#cda243`, text set in `#061410` (weight 600) with a pill-influenced `rounded-2xl` contour. Subtle inset shimmer on top edge.
  - *Secondary Glass Button:* Translucent dark emerald backdrop (`#0b221c`) with a `1px` border of `rgba(229, 185, 95, 0.4)` and ivory text.
- **Cards & Containers:**
  - Constructed using frosted glass surfaces with high-blur diffusion (`backdrop-filter: blur(20px)`), filled with `rgba(8, 26, 21, 0.8)`. Outlined with a continuous hairline border in muted gold or deep celadon.
- **Chips & Badges:**
  - Compact rounded capsules (`rounded-full`) used for prayer times, milestone markers, and Tawaf lap numbers. Outlined in `rgba(134, 187, 164, 0.3)` with soft celadon text.
- **Form Inputs:**
  - Deep recessed backgrounds (`#040d0a`) accented by smooth inner borders. Focus state illuminates with a soft `#e5b95f` border and gentle outer gold aura glow.
- **Checkboxes & Selection Controls:**
  - Custom geometric checkboxes with gold borders. Checked state reveals an animated metallic fill with an ivory glyph checkmark.
- **Domain-Specific Components:**
  - *Tawaf / Sa'i Counter:* Circular progress dial featuring a dual-ring track—obsidian emerald base ring tracked by a glowing metallic gold segment with haptic feedback.
  - *Dua & Verse Reader:* Expansive card with dignified `Newsreader` typography, generous vertical line height, and a faint geometric arabesque watermark embedded in the frosted background.