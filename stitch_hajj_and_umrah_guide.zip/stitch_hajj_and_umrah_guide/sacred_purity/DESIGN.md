---
name: Sacred Purity
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#6b5d3d'
  on-secondary: '#ffffff'
  secondary-container: '#f2ddb5'
  on-secondary-container: '#706141'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0d1c2e'
  on-tertiary-container: '#77859a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#f5e0b8'
  secondary-fixed-dim: '#d8c49e'
  on-secondary-fixed: '#241a03'
  on-secondary-fixed-variant: '#524527'
  tertiary-fixed: '#d5e3fc'
  tertiary-fixed-dim: '#b9c7df'
  on-tertiary-fixed: '#0d1c2e'
  on-tertiary-fixed-variant: '#3a485b'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  title-sm:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system reflects the sacred state of *Ihram*—unstitched, undifferentiated, and pure. It strips away ornamental distraction to evoke feelings of tranquility, equality, spiritual clarity, and humility. The interface feels weightless and vast, like an open desert courtyard bathed in dawn light.

The design philosophy combines **Spiritual Minimalism** and **Architectural Serenity**:
- **Pure Canvas:** Vast fields of unadorned white and misty unbleached linen evoke an atmosphere of pristine calm.
- **Intentional Restraint:** Every element must justify its presence. Uncluttered whitespace is an active structural element, not an empty void.
- **Quiet Dignity:** Micro-interactions are deliberate and measured. Visual feedback uses soft tone shifts rather than loud animations.
- **Audience & Touchpoints:** Designed for high-focus spiritual companions, quiet reflection applications, pilgrimage navigators, and sacred reading experiences demanding extreme legibility and zero visual noise.

## Colors

The palette is derived from natural limestone, bleached cotton, and the deep obsidian stone of timeless monuments.

- **Primary (`#0f172a`):** Deep Slate Obsidian. Used for high-contrast, razor-sharp typography, key active states, and focal icons.
- **Secondary (`#8a7a58`):** Desert Limestone / Soft Ochre. Used selectively for sacred markers, subtle active highlights, indicators, and meditative accents. Never applied loudly.
- **Tertiary (`#475569`):** Weathered Basalt. Serves secondary typography, captions, and structural glyphs.
- **Neutral Canvas (`#f8fafc`):** Misty Linen White. Complemented by pure white (`#ffffff`) for elevated panels and whisper-soft hairlines (`#e2e8f0` and `#eef2f6`).

### Usage Rules
- Avoid stark saturated primaries. Color is applied with gentle precision to maintain an atmosphere of quiet contemplation.
- Semantic feedback states must use muted tones: soft sage for completion (`#2e6f40`), warm amber for caution (`#926018`), and quiet terracotta for errors (`#9f2d2d`).

## Typography

The typography pairing unites the literary grace of **Newsreader** with the structured, contemporary clarity of **Manrope**.

- **Headlines (Newsreader):** Carries an editorial, manuscript-level dignity. Letterforms evoke classic lithography and traditional stone inscriptions. Used in light and medium weights to preserve delicate line stems.
- **Body & Controls (Manrope):** Clean, geometric, and balanced. Provides seamless reading across both long-form texts and compact utility labels.
- **Letter Spacing:** Headlines utilize tight negative tracking to maintain cohesion. Micro-labels, meta data, and chapter markers adopt generous tracking (`0.06em` to `0.08em`) with uppercase styling for balanced architectural anchors.

## Layout & Spacing

The layout is grounded in expansive breathing space. Negative space acts as a quiet boundary, separating modules through distance rather than heavy visual lines.

- **Grid Architecture:** A 12-column responsive fluid grid on desktop (`>1024px`) with wide `3rem` margins and `1.5rem` gutters. Collapses to 8 columns on tablet (`768px-1023px`) and 4 columns on mobile (`<768px`) with `1.25rem` margins.
- **Vertical Rhythm:** Generous vertical rhythm utilizing `space-xl` (`3rem`) to partition sections. Content density is kept intentionally low to preserve mental stillness.
- **Container Constancy:** Primary text and meditative reading passages are constrained to a max-width of `680px` centered on canvas to ensure optimal line lengths without eye fatigue.

## Elevation & Depth

Visual hierarchy rejects artificial dropshadows and heavy layer offsets. Instead, depth is established through tonal purity and subtle edge treatments:

- **Surface Tiers:**
  - *Base Layer (Canvas):* Misty Linen White (`#f8fafc`).
  - *Primary Surface (Cards, Modules):* Pure Seamless White (`#ffffff`).
  - *Secondary Surface (Wells, Insets):* Pale Mist (`#f1f5f9`).
- **Whisper-Soft Borders:** Surfaces are delineated by crisp 1px hairline borders (`#e2e8f0` / `#edf2f7`). 
- **Subtle Elevation:** For floating modals, persistent navigation, or search trays, use an ultra-diffused, whisper-soft ambient glow: `0 8px 32px -4px rgba(15, 23, 42, 0.03), 0 2px 8px -2px rgba(15, 23, 42, 0.02)`. Heavy drop shadows are strictly prohibited.

## Shapes

The shape system employs continuous, soft geometric curves reflecting smooth marble and natural river stone.

- **Base Radius (`roundedness: 2`):** Base components like inputs, standard buttons, and alert modules feature `0.5rem` (8px) corners.
- **Containers & Panels:** Cards, dialogs, and larger modules use `rounded-lg` (`1rem` / 16px) or `rounded-xl` (`1.5rem` / 24px) to create an inviting, unhurried posture.
- **Seamless Continuity:** Nested elements mirror parent curvature (nested corner radius = parent radius minus internal padding) to maintain geometric harmony.

## Components

### Buttons
- **Primary:** Background `#0f172a`, text `#ffffff`, border radius `0.5rem`, height `44px`, padding `0 1.5rem`. Hover state softly transitions to `#1e293b`.
- **Secondary / Outline:** Background `#ffffff`, text `#0f172a`, hairline border `1px solid #e2e8f0`. Hover: background shifts to `#f8fafc` with border `#cbd5e1`.
- **Subtle Text:** Background transparent, text `#475569`, hover text `#0f172a`.

### Cards & Surfaces
- Grounded in pure white (`#ffffff`) over misty canvas (`#f8fafc`).
- Encased with a single hairline border (`1px solid #edf2f7`), internal padding of `space-lg` (`1.75rem`), and corner radius of `1rem`. Zero harsh shadows.

### Input Fields
- Background `#ffffff`, height `48px`, border `1px solid #e2e8f0`, corner radius `0.5rem`, text `#0f172a`.
- Placeholder text in `#94a3b8`.
- Focus state: border shifts to `#8a7a58` with a clean `0 0 0 1px #8a7a58` outline. No glowing neon halos.

### Chips & Filter Tags
- Height `32px`, corner radius `1rem`, background `#ffffff`, border `1px solid #e2e8f0`, text `#475569`, font size `13px`.
- Active State: Background `#0f172a`, text `#ffffff`, border `#0f172a`.

### Checkboxes & Radios
- Size `20px` by `20px`, 1px border `#cbd5e1`, background `#ffffff`.
- Checked State: Fill `#0f172a` with a pure white glyph. Radios follow concentric circle styling with a `6px` solid inner obsidian dot.

### Lists & Dividers
- Lists prioritize generous row padding (`1rem` vertical) with full-width or inset hairlines (`#f1f5f9`).
- Dividers are never heavy rules; they appear as feather-light 1px breaks with generous spacing before and after.

### Sacred Focal Modules (Verses, Du'a & Reflections)
- Distinct contemplation containers rendered on an unbleached tinted ground (`#fafaf9`), centered typography in Newsreader with subtle gold accent markers (`#8a7a58`), and generous breathing room (`2.5rem` padding).