---
name: Sacred Rawdah
colors:
  surface: '#00170f'
  surface-dim: '#00170f'
  surface-bright: '#1e3f33'
  surface-container-lowest: '#00120b'
  surface-container-low: '#002117'
  surface-container: '#01251a'
  surface-container-high: '#0d3024'
  surface-container-highest: '#193b2f'
  on-surface: '#c5ebda'
  on-surface-variant: '#c0c8c3'
  inverse-surface: '#c5ebda'
  inverse-on-surface: '#14362b'
  outline: '#8a938e'
  outline-variant: '#404944'
  surface-tint: '#a0d1bc'
  primary: '#a0d1bc'
  on-primary: '#033829'
  primary-container: '#0a3d2e'
  on-primary-container: '#78a894'
  inverse-primary: '#396756'
  secondary: '#e9c349'
  on-secondary: '#3c2f00'
  secondary-container: '#af8d11'
  on-secondary-container: '#342800'
  tertiary: '#62dcad'
  on-tertiary: '#003827'
  tertiary-container: '#003e2b'
  on-tertiary-container: '#31b286'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#bbedd7'
  primary-fixed-dim: '#a0d1bc'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#204f3f'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#80f9c8'
  tertiary-fixed-dim: '#62dcad'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#00513a'
  background: '#00170f'
  on-background: '#c5ebda'
  surface-variant: '#193b2f'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.01em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 34px
    fontWeight: '400'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: '0'
  headline-md:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: '0'
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system draws visual reverence from Al-Rawdah Al-Sharifah in Al-Masjid an-Nabawi: the deep velvet botanical greens of the sacred carpet, polished Carrara marble pillars, gilded brass lattices, and soft ambient sanctuary illumination. 

### Brand Personality & Emotional Intent
- **Reverent Serenity:** Every screen acts as a quiet sanctuary. High information density is avoided in favor of calm, contemplative spatial rhythm.
- **Noble Heritage:** Gold and antique brass accents are applied deliberately to signify sacred value, spiritual reflection, and exquisite craftsmanship, avoiding commercial flashiness.
- **Luminous Solace:** The interface evokes night prayers under cool marble arches, bathed in a low emerald glow with gold filigree highlights.

### Design Movement
The interface blends **Sacred Heritage Editorial** with **Soft Ambient Glassmorphism**:
- Deep velvet pine and forest surfaces create layered, non-glare visual grounding.
- Subdued emerald and mint backdrops emit soft localized radiance beneath key focal points.
- Fine filigree hairline borders in muted antique gold frame elevated surfaces, evoking historic brass lattice screens.

## Colors

The color palette is rooted in the physical architecture of the Rawdah: deep vegetative greens, radiant luminous mint, brass gilding, and marble whites.

### Palette Architecture

- **Primary (`#0A3D2E`):** Sacred Forest Green. Used for elevated interactive components, active state backdrops, and core brand anchoring.
- **Secondary (`#D4AF37`):** Noble Gold. Used for spiritual highlights, badge flourishes, selected tab indicators, subtle borders, and delicate ornamental emblems.
- **Tertiary (`#6EE7B7`):** Luminous Mint. High-visibility indicator for live prayer phases, active reading progress, and glow accents.
- **Neutral Surface Baseline (`#072B20`):** Velvet Pine. The foundational canvas backdrop, ensuring optical comfort in low-light environments.

### Applied Tokens & Roles

- **Canvas Background:** `#072B20`
- **Surface Level 1 (Panels & Cards):** `#0A3D2E` with 60% opacity on layered backdrops.
- **Surface Level 2 (Floating Modals & Sheets):** `#0E4F3B`
- **Surface Level 3 (Inputs & Recessed Trays):** `#052018`
- **Primary Text:** `#F2F9F5` (Crisp Alabaster)
- **Secondary / Subdued Text:** `#A3C2B3` (Soft Pale Sage)
- **Border & Hairline Trims:** `#D4AF37` at 22% opacity (`rgba(212, 175, 55, 0.22)`)
- **Glow & Highlights:** `#4ADE80` at 12% opacity blur for ambient halos.

## Typography

The type system balances sacred literary beauty with contemporary legibility across reading and utilitarian flows.

- **Headline Hierarchy (`Noto Serif`):** Conveys timeless dignity and editorial authority. Used exclusively for surah titles, prayer milestones, screen headings, and contemplative passages. Titles maintain comfortable line spacing to accommodate both Latin and Arabic script balance.
- **Body & Label Hierarchy (`Manrope`):** A modern, geometric grotesque with gentle curvature that harmonizes with Noto Serif without competing for attention. Ensures maximum legibility for devotional commentary, timestamps, and settings.
- **Type Scale Rules:** Display text switches to `display-lg-mobile` below 768px viewports. Headers should never be styled in full uppercase; small labels may use uppercase only with generous letter tracking (`0.05em` to `0.08em`).

## Layout & Spacing

The layout is built upon an 8pt spatial grid designed to encourage breathing room and unhurried contemplation.

### Layout Model
- **Canvas System:** A responsive 12-column grid on desktop (max width: 1200px, centered) transitioning to an 8-column layout on tablets and a 4-column layout on mobile.
- **Margins & Gutters:** Generous outer margins (`2.5rem` on desktop, reducing to `1.25rem` on mobile) isolate content from the viewport edges, reinforcing sanctuary framing.
- **Vertical Rhythm:** Generous vertical sections separated by `space-xl` prevent perceptual clutter, giving equal dignity to text and surrounding white space.

### Breakpoints & Adaptations
- **Mobile (< 768px):** Stacks multi-column prayer panels into scrollable single-column architectural cards. Navigation transitions from top bar to an elevated floating bottom bar.
- **Tablet (768px – 1024px):** 2-column asymmetric split (e.g., devotional stream on the left, daily prayer tracker on the right).
- **Desktop (> 1024px):** 12-column layout centered with ample negative space flanking the content container.

## Elevation & Depth

Visual depth is achieved through translucent emerald glass layering and antique gold hairline framing, rather than deep muddy dropshadows.

### Elevation Hierarchy
- **Level 0 (Sanctuary Bed):** Solid `#072B20`. Provides a grounded, deep velvet green base.
- **Level 1 (Card & Module Layer):** `#0A3D2E` at 85% opacity with an ambient backdrop blur of `16px`. Outlined with a fine `1px` border of `#D4AF37` at 18% opacity. Casts a soft shadow: `0 8px 24px -4px rgba(2, 20, 15, 0.45)`.
- **Level 2 (Floating Navigation & Dialogs):** `#0E4F3B` at 92% opacity with `24px` backdrop blur. Outlined with `1px` border of `#D4AF37` at 28% opacity. Casts an ambient shadow: `0 16px 36px -6px rgba(1, 14, 10, 0.6)`.
- **Emerald Halos & Accents:** High-priority cards (such as the active prayer or highlighted verse) cast a faint radial green halo behind their container using `rgba(74, 222, 128, 0.08)` with a `48px` blur.

## Shapes

The shape vocabulary evokes the gentle curves of Moorish and Nabawi arches: soft, organic, and welcoming.

- **Base Radius:** Components use roundedness scale `2` (`0.5rem` / `8px` default).
- **Surfaces & Cards (`rounded-xl`):** `1.5rem` (`24px`) radii on structural cards produce arched, cushioned tactile surfaces reminiscent of handwoven carpet panels.
- **Pill Accents:** Chips, status tags, and primary action buttons utilize full capsule pills (`9999px`) to soften interaction points and offer warm contrast against architectural cards.

## Components

### Buttons
- **Primary Button:** Pill-shaped (`rounded-full`), filled with `#D4AF37` (Noble Gold) with `#072B20` deep pine text. On hover, subtly brightens to `#E5C365` with a faint gold ambient glow (`0 0 16px rgba(212, 175, 55, 0.35)`).
- **Secondary Button:** Pill-shaped, tinted `#0A3D2E` background with a `1px` border of `#D4AF37` (35% opacity), styled with `#F2F9F5` alabaster text.
- **Ghost Button:** Unfilled, styled with `#6EE7B7` (Luminous Mint) text and subtle mint hover highlight.

### Cards
- **Architecture:** Constructed on Surface Level 1 with `1.5rem` curvature.
- **Borders & Ornamentation:** A continuous `1px` hairline stroke in `#D4AF37` (18% opacity). Key feature cards feature a subtle ornamental arch notch or gold floral pip at the top center.
- **Padding:** Governed by `space-lg` (`1.5rem`) internally.

### Chips & Badges
- **Status Chips:** Capsule-shaped with `#072B20` fill, `1px` border in `#6EE7B7` (30% opacity), and `#6EE7B7` label text.
- **Sacred Tags:** `#D4AF37` at 12% background fill with solid `#D4AF37` text and micro tracking (`label-sm`).

### Form Inputs
- **Text Fields:** Recessed `#052018` background, `0.75rem` (`12px`) border radius, hairline border in `#125B44`. Focus shifts border to `#6EE7B7` with an inner glow of `rgba(110, 231, 183, 0.15)`.
- **Placeholders:** Styled in pale sage (`#A3C2B3` at 50% opacity).

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** Squared with `6px` radius; unchecked state has a `1.5px` border of `#125B44`. Checked state fills with `#D4AF37` displaying an `#072B20` checkmark.
- **Radio Buttons:** Concentric circles; selected state reveals an inner disc of `#6EE7B7` surrounded by a `#072B20` air gap and `#6EE7B7` outer ring.

### Lists
- **Devotional Lists:** Clean horizontal rows divided by hairline gradient rules (`rgba(212, 175, 55, 0.15)` fading to transparent at the edges).
- **Leading Elements:** Numbered sequence pips set in Noto Serif within a soft gold disc outline.