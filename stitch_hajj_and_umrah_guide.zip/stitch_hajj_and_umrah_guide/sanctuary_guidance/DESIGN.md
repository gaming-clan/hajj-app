---
name: Sanctuary Guidance
colors:
  surface: '#f7faf6'
  surface-dim: '#d8dbd7'
  surface-bright: '#f7faf6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f1'
  surface-container: '#ecefeb'
  surface-container-high: '#e6e9e5'
  surface-container-highest: '#e0e3e0'
  on-surface: '#181c1b'
  on-surface-variant: '#404944'
  inverse-surface: '#2d312f'
  inverse-on-surface: '#eef1ee'
  outline: '#707974'
  outline-variant: '#c0c9c3'
  surface-tint: '#336855'
  primary: '#002f22'
  on-primary: '#ffffff'
  primary-container: '#0d4736'
  on-primary-container: '#7fb59f'
  inverse-primary: '#9bd2bb'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#003015'
  on-tertiary: '#ffffff'
  tertiary-container: '#054924'
  on-tertiary-container: '#7ab889'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b6eed6'
  primary-fixed-dim: '#9bd2bb'
  on-primary-fixed: '#002117'
  on-primary-fixed-variant: '#19503e'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#b1f2be'
  tertiary-fixed-dim: '#96d5a3'
  on-tertiary-fixed: '#00210d'
  on-tertiary-fixed-variant: '#12512c'
  background: '#f7faf6'
  on-background: '#181c1b'
  surface-variant: '#e0e3e0'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 44px
    letterSpacing: -0.01em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-md:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system serves pilgrims navigating Hajj and Umrah under physically and emotionally demanding circumstances. The atmosphere balances deep spiritual reverence with rigorous utilitarian clarity. The emotional tone is tranquil, dignified, focused, and authoritative—eradicating doubt and visual friction in intense environments such as high heat and bright midday sunlight.

The aesthetic fuses modern refined minimalism with understated tactile warmth and subtle Islamic architectural symmetry. Interface layers evoke stone courtyards, parchment, and polished brass markers rather than ephemeral digital novelty. Pure visual decoration is suppressed in favor of generous whitespace, crystalline typographic hierarchy, structured geometric accents, and unambiguous ritual status signaling.

## Colors

The palette is anchored in sacred deep emerald green, balanced by brushed antique gold, set against pearl-toned luminous surfaces:

- **Primary (`#0D4736`):** Deep emerald sanctuary green. Used for high-emphasis containers, top-level navigation, primary ritual actions, and authoritative headings.
- **Secondary (`#C5A059`):** Brushed gold/brass. Reserved for sacred highlights, active step indicators, verification icons, and secondary focus states.
- **Tertiary (`#14532D`):** Forest emerald shade. Used for depth shifts, nested sub-navigation, and high-legibility tonal surfaces.
- **Neutral (`#212523`):** Carbon stone charcoal. Used for primary text on light backgrounds, exceeding WCAG AAA standards (minimum 7:1) to guarantee visibility under direct desert sunlight.

### Extended Semantic Tokens
- **Canvas Base:** `#F9FAF8` (pearl alabaster)
- **Surface Clean:** `#FFFFFF` (pure white for cards and modal sheets)
- **Surface Muted:** `#F0F3EF` (neutral container background)
- **Status Allowed (Halal / Permissible):** `#0F5B3E` (deep sage green surface: `#EAF5EE`, border: `#B5E3C8`)
- **Status Prohibited (Haram / Prohibited in Ihram):** `#9E2A2B` (ruby crimson surface: `#FDF2F2`, border: `#F5B8B9`)
- **Status Penalty (Fidya / Kaffarah Required):** `#B45309` (amber brass surface: `#FFFBEB`, border: `#FCD34D`)

## Typography

The typographic pairing balances reverent editorial grace with ergonomic legibility:

- **Headlines & Ritual Names (`Newsreader`):** An elegant, literary serif chosen for spiritual authority, dignified ritual naming, and contemplative reading. Used for screen titles, surah/dua titling, and major milestone markers.
- **Body & Functional UI (`Plus Jakarta Sans`):** A modern, warm geometric sans-serif featuring generous aperture and sturdy letterforms. Ensures maximum reading comfort during movement, crowds, and bright daylight.
- **Numbers & Counters:** Step sequences and Tawaf/Sa'i lap counters utilize bold tabular figures from `Plus Jakarta Sans` to prevent layout shift during active incrementation.

## Layout & Spacing

The layout is built around mobile-first utility, accommodating single-handed usage while walking:

- **Grid Architecture:** 4-column layout on mobile devices (`<600px`), shifting to 8 columns on tablets (`600px - 1024px`) and 12 columns for desktop reference interfaces (`>1024px`).
- **Touch-Friendly Margins:** Outer margin is locked to `1rem` on mobile to optimize screen real estate while maintaining safe thumb margins.
- **Spacious Vertical Cadence:** Generous section spacing (`space-xl`) prevents visual overwhelm when presenting dense legal rulings or multistep ritual sequences.

## Elevation & Depth

Visual hierarchy is maintained through subtle tonal layering and ambient warmth rather than artificial drops:

- **Surface Levels:** 
  - Level 0 (Base Canvas): `#F9FAF8`
  - Level 1 (Primary Cards): `#FFFFFF` with an ambient warm shadow (`0 2px 8px -2px rgba(13, 71, 54, 0.05), 0 1px 3px 0 rgba(0, 0, 0, 0.03)`) and a delicate `1px` border in `#E5EAE3`.
  - Level 2 (Floating Action Sheets & Modals): Elevated with `0 12px 32px -8px rgba(13, 71, 54, 0.12), 0 4px 12px -2px rgba(0, 0, 0, 0.04)`.
- **Islamic Tessellation Depth:** Subtle vector eight-pointed star (Khatim) geometry is applied via low-opacity (2% to 4%) SVG overlays on Level 0 and emerald header blocks, adding sacred texture without compromising contrast.

## Shapes

The interface embraces a tailored organic softness using rounded rectangles paired with full pill boundaries for focal elements:

- **Cards & Content Blocks:** Utilize `0.5rem` (`rounded`) to `1rem` (`rounded-lg`) corner radii, conveying peaceful, non-aggressive architectural enclosures.
- **Pill Shapes:** Status badges, interactive ritual buttons, search containers, and bottom navigation pills use full rounded caps (`rounded-full` / `9999px`) to create smooth, touchable surfaces that prevent thumb fatigue.

## Components

### Buttons
- **Primary Action (Emerald Pill):** Solid `#0D4736` fill, `#FFFFFF` text (`label-lg`), pill shape (`rounded-full`), min-height `52px` for effortless tap ergonomics in crowds.
- **Secondary Action (Gold Outline):** `1.5px` border in `#C5A059`, `#0D4736` text, transparent background, pill shape.
- **Tertiary Action:** Flat `#F0F3EF` background, `#212523` text.

### Status Badges (Ritual Compliance)
Compact pill containers (`rounded-full`, horizontal padding `12px`, vertical padding `4px`) featuring high-contrast icon + text:
- **Allowed (Mubah/Halal):** Sage green background `#EAF5EE`, border `#B5E3C8`, text `#0F5B3E`.
- **Prohibited (Mahzur):** Soft rose background `#FDF2F2`, border `#F5B8B9`, text `#9E2A2B`.
- **Penalty / Fidya:** Soft amber background `#FFFBEB`, border `#FCD34D`, text `#B45309`.

### Ritual Progress & Lap Counter Cards
- White `#FFFFFF` surface container, `1rem` corner radius, `1px` border in `#E5EAE3`.
- Incorporates high-legibility numerical dials (e.g., "Lap 3 of 7" in Tawaf) with emerald accent fill and brass completion checkmarks.

### Input Fields & Search
- Full pill (`rounded-full`) search bars with `#FFFFFF` background, `1px` border in `#DDE3DB`, and `#0D4736` icon accents.
- Focus state switches border to `#C5A059` with a subtle `2px` ring in `#C5A05920`.

### Dua & Ruling Expansion Lists
- Divided rows with clean `#F0F3EF` separators.
- Collapsible cards featuring Arabic calligraphy or prayer text in dedicated high-contrast serif blocks, paired with translation and ruling chips directly underneath.