---
name: Hijaz Golden Dawn
colors:
  surface: '#fff8f4'
  surface-dim: '#ead7c1'
  surface-bright: '#fff8f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e4'
  surface-container: '#feebd5'
  surface-container-high: '#f8e5cf'
  surface-container-highest: '#f3e0ca'
  on-surface: '#231a0d'
  on-surface-variant: '#514536'
  inverse-surface: '#392f20'
  inverse-on-surface: '#ffeedc'
  outline: '#837564'
  outline-variant: '#d6c4b1'
  surface-tint: '#845400'
  primary: '#805200'
  on-primary: '#ffffff'
  primary-container: '#a16801'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb958'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fdb963'
  on-secondary-container: '#754900'
  tertiary: '#785600'
  on-tertiary: '#ffffff'
  tertiary-container: '#976d00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffddb6'
  primary-fixed-dim: '#ffb958'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#fdb963'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#f7bd44'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#fff8f4'
  on-background: '#231a0d'
  surface-variant: '#f3e0ca'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Newsreader
    fontSize: 19px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0em
  body-md:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-sm:
    fontFamily: Newsreader
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality is contemplative, dignified, sacred, and reassuringly grounded. Designed for pilgrims undertaking Hajj and Umrah, the interface evokes the golden dawn rising across the plains of Arafat, the timeless warmth of desert limestone, and the quiet tactile dignity of classical Islamic manuscripts.

The aesthetic philosophy fuses **Minimalist Editorial** with **Tactile Parchment** qualities:
- **Atmosphere:** Deeply serene, reverent, and focused. Distractions, flashy neon indicators, and aggressive gamification are eliminated.
- **Visual Weight:** Light-filled, organic warmth supported by generous breathing room and editorial balance.
- **Emotional Intent:** To instill presence, tranquility (*itmi'nan*), and effortless clarity amidst physically demanding and emotionally transformative spiritual journeys.

## Colors

The palette draws directly from the natural materials and sacred landscapes of the Hijaz: sunlit desert horizons, raw ochre pigment, aged vellum, and deep roasted espresso.

- **Primary (`#b47818`) & Secondary (`#945f0d`):** Warm golden ochre and deep camel amber. Applied to primary actions, spiritual step markers, active ritual indicators, and key touchpoints.
- **Tertiary (`#e5ad35`):** Radiant golden amber. Used selectively for illuminated accents, active borders, completion badges, and delicate ornamental framing.
- **Neutral (`#2c2214`):** Warm espresso/roasted charcoal. Delivers high-contrast, low-fatigue legibility without the harshness of pure black.
- **Canvas & Containers:** 
  - Base canvas: `#faf6ef` (glowing desert sand).
  - Surface container elevated: `#fdf9f2` (warm parchment).
  - Surface container pure: `#ffffff` (sun-washed linen).
  - Subtle structural border: `rgba(180, 120, 24, 0.16)`.

## Typography

The typographical pairing reflects scholarly tradition blended with modern navigational precision.

- **Newsreader (Headlines & Body):** An editorial serif providing optical warmth, classical proportion, and bookish authority. Used for all prayer texts, du'a translations, step-by-step guidance narratives, and introspective section headers. Its italics bring poetic cadence to supplications and transliterations.
- **Manrope (Labels & Utility UI):** A balanced, clean sans-serif deployed strictly for functional telemetry: ritual step counters, timestamps, compass bearings, progress metadata, and interactive states.

## Layout & Spacing

The layout utilizes a fluid, responsive structure grounded in consistent vertical cadence. Content never feels cramped, honoring the meditative mindset required during pilgrimage.

- **Mobile (< 768px):** 4-column fluid grid, `1rem` outer canvas margins, and `1rem` gutters. Primary reading and ritual views are centered with strict single-column flow to reduce peripheral distraction.
- **Tablet (768px – 1024px):** 8-column layout, `2rem` margins, enabling parallel sidebars for ritual progress alongside spiritual texts.
- **Desktop (> 1024px):** 12-column layout capped at `1120px` max-width. Generous margins (`3rem`) preserve optimal reading line lengths for Quranic and supplication verses.

## Elevation & Depth

Visual hierarchy is communicated through **Tonal Parchment Layers** and **Warm Ambient Shadows**, avoiding sterile artificial drop shadows.

- **Level 0 (Base Canvas):** `#faf6ef` desert sand floor.
- **Level 1 (Parchment Surfaces):** `#fdf9f2` containers framed by a delicate `1px` stroke of `rgba(180, 120, 24, 0.12)`.
- **Level 2 (Cards & Active Steppers):** `#ffffff` layered over the sand canvas with an ambient shadow: `0 4px 20px -2px rgba(44, 34, 20, 0.05), 0 2px 6px -1px rgba(180, 120, 24, 0.04)`.
- **Level 3 (Modal Sheets & Prayer Cards):** Raised modal sheets with `0 12px 32px -4px rgba(44, 34, 20, 0.09)` and a top hairline border of `#e5ad35`.

## Shapes

The design adopts a **Rounded (`2`)** shape system. Corners are softened like stones smoothed by desert winds and worn leather binding edges.

- Base component containers (inputs, cards, banners): `0.5rem` (8px).
- Modals, prominent ritual cards, and step modules: `1rem` (16px).
- Overlays and primary action capsules: `1.5rem` (24px) or full circular pills where focused repetition is needed (e.g., *Tasbih* counter dials).

## Components

### Buttons
- **Primary:** Filled `#b47818` with `#ffffff` text, subtle 0.5px inner border of `rgba(255, 255, 255, 0.25)`. Pressed state transitions to `#945f0d`.
- **Secondary / Outlined:** `#fdf9f2` background with a 1px border of `rgba(180, 120, 24, 0.35)` and `#945f0d` text.
- **Tertiary / Ghost:** Transparent background, `#945f0d` text with an underline accent on hover.

### Chips & Badges
- **Status Badges (e.g., "Tawaf Complete", "Sunnah"):** Subtle tinted background `rgba(229, 173, 53, 0.12)`, text `#945f0d`, and border `rgba(229, 173, 53, 0.4)`.
- **Filter Chips:** Parchment `#fdf9f2` with subtle espresso text. When active, fill switches to `#b47818` with white typography.

### Lists
- Separated by soft hairline rules of `rgba(180, 120, 24, 0.1)`.
- List items feature Newsreader titles with Manrope metadata counters placed in high-visibility trailing slots.

### Input Fields
- Background `#fdf9f2`, border `1px solid rgba(180, 120, 24, 0.25)`.
- Focused state applies a clear `#b47818` border and an ambient golden glow `0 0 0 3px rgba(229, 173, 53, 0.2)`. Label remains high-contrast `#2c2214`.

### Checkboxes & Radio Buttons
- Rounded and radio frames use `#945f0d` borders. Selected states feature a solid `#b47818` fill with clean white interior check/dot indicators.

### Cards
- Constructed with `#ffffff` or `#fdf9f2`, carrying a `1px` border of `rgba(180, 120, 24, 0.14)`.
- Dedicated ritual cards feature an optional top accent line in `#e5ad35` (2px) to denote active spiritual milestones.

### Domain-Specific Components
- **Du'a Verse Tile:** Card with dual-typography display: prominent Arabic script with proportional breathing room, followed by Newsreader italicized English translation and Manrope reference attribution.
- **Ritual Progress Stepper:** A vertical or horizontal timeline using camel amber `#945f0d` milestones connected by delicate golden ochre thread lines.
- **Tasbih / Dhikr Tap Counter:** Large tactile circular target with a warm gradient ring and tactile haptic feedback indicators.